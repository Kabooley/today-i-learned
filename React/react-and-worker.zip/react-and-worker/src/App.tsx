import React, { useState } from 'react';
// import FunctionalCase from './FunctionalCase';
import ClassCase from './ClassCase';

const App = () => {
    const [, forceRerender] = useState<undefined>();

    const handleClick = () => {
        console.log("rerender");
        forceRerender(undefined);
    }

    return (
        <div className="app">
            {/* <FunctionalCase /> */}
            <ClassCase />
            <button onClick={handleClick}>rerender</button>
        </div>
    );
};

export default App;
