import React from 'react';
import type { iResponse, iRequest } from './worker/Counter.worker';

interface iProps {}
interface iState {}

class ClassCase extends React.Component<iProps, iState> {
    state = {
        counter: 0,
    };
    _worker: Worker | undefined;

    constructor(props: iProps) {
        super(props);
        this.handleMessage = this.handleMessage.bind(this);
        this.handleClick = this.handleClick.bind(this);
    }

    componentDidMount() {
        console.log('did mount');
        if (window.Worker && this._worker === undefined) {
            console.log('generate and setup worker');

            this._worker = new Worker(
                new URL('/src/worker/Counter.worker.ts', import.meta.url)
            );
            this._worker.addEventListener('message', this.handleMessage);
        }
    }

    componentDidUpdate() {
        console.log('did update');
    }

    componentWillUnmount(): void {
        if (window.Worker && this._worker !== undefined) {
            console.log('terminate worker');

            this._worker.removeEventListener('message', this.handleMessage);
            this._worker.terminate();
            this._worker = undefined;
        }
    }

    handleMessage(e: MessageEvent<iResponse>) {
        const { count } = e.data;
        console.log(`Got message from worker: ${count}`);
        this.setState({ counter: count });
    }

    handleClick() {
        console.log('click');

        if (this._worker === undefined) return;

        this._worker.postMessage({
            count: this.state.counter,
            order: 'calculate',
        } as iRequest);
    }

    render() {
        return (
            <div className="functional-case">
                <h2>In case functional component with Worker</h2>
                <button onClick={this.handleClick}>count up</button>
                <h2>{this.state.counter}</h2>
            </div>
        );
    }
}

export default ClassCase;
