import React, { useEffect, useMemo, useState, useRef } from 'react';
import type { iRequest, iResponse } from './worker/Counter.worker';

const FunctionalCase = () => {
    const [counter, setCounter] = useState<number>(0);
    const refWorker = useRef<Worker>();

    // const worker: Worker = useMemo(
    //     () =>
    //         new Worker(
    //             new URL('/src/worker/Counter.worker.ts', import.meta.url)
    //         ),
    //     []
    // );

    useEffect(() => {
        console.log('did mount');
        console.log(refWorker.current);

        // if (window.Worker) {
        //     console.log('set message listener');

        //     worker.addEventListener('message', handleWorkerMessage);
        // }

        if (window.Worker && refWorker.current === undefined) {
            console.log('Generate worker and set message listener');

            refWorker.current = new Worker(
                new URL('/src/worker/Counter.worker.ts', import.meta.url)
            );
            refWorker.current.addEventListener('message', handleWorkerMessage);
        }

        return () => {
            if (window.Worker && refWorker.current) {
                console.log('terminate worker');

                // worker.removeEventListener('message', handleWorkerMessage);
                // worker.terminate();

                refWorker.current.removeEventListener(
                    'message',
                    handleWorkerMessage
                );
                refWorker.current.terminate();
                // NOTE: 重要。worker.terminate()だけだとrefはworkerインスタンスを保持したままになる。
                refWorker.current = undefined;
            }
        };
    }, []);

    // 依存関係にworkerを含めることに意味はあるか？

    const handleWorkerMessage = (e: MessageEvent<iResponse>) => {
        const { count } = e.data;
        console.log(`Got message from worker: ${count}`);
        setCounter(count);
    };

    const handleClick = () => {
        console.log('click');

        if (refWorker.current === undefined) return;

        refWorker.current.postMessage({
            count: counter,
            order: 'calculate',
        } as iRequest);
    };

    return (
        <div className="functional-case">
            <h2>In case functional component with Worker</h2>
            <button onClick={handleClick}>count up</button>
            <h2>{counter}</h2>
        </div>
    );
};

export default FunctionalCase;
