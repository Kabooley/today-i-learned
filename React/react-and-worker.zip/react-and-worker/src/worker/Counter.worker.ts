export interface iRequest {
    order: 'calculate';
    count: number;
}

export interface iResponse {
    count: number;
}

const expensiveCalculator = (val: number) => {
    let result = val;
    for (let i = 0; i < 10000; i++) {
        result += 1;
    }
    return result;
};

console.log('[Counter.worker] running...');

self.addEventListener('message', (e: MessageEvent<iRequest>) => {
    const { order, count } = e.data;
    // To ignore other posted message.
    if (order !== 'calculate') return;

    console.log('[Counter.worker] got request');

    const result = expensiveCalculator(count);

    console.log('[Counter.worker] send result');

    self.postMessage({
        count: result,
    });
});
