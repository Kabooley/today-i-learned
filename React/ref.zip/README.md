# React ref について学習した内容のサンプルコード

詳しくは TIL の該当ノートを参照。

## `src/caseParentRefNOwnRef`

親コンポーネントからの ref と自コンポーネントの ref を両方を一つの DOM に渡さないときにどうするべきかをまとめた。

## `src/caseDynamicRefArray`

動的配列から生成される各要素すべてに ref を渡したいときにどうするべきかをまとめた。
