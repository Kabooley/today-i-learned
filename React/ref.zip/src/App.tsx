import "./styles.css";
// import ResizableScrollableTabs from "./caseParentRefNOwnRef/base";
// import ResizableScrollableTabs from "./caseParentRefNOwnRef/caseUseImperativeHandle";
import ResizableScrollableTabs from "./caseParentRefNOwnRef/caseCallbackRef";

export default function App() {
  return (
    <div className="App">
      <ResizableScrollableTabs />
    </div>
  );
}
